
# Subpass

Pass 和 Subpass 的具体定义和理解已经在**概念汇总**章节介绍过，此处不再赘述。

