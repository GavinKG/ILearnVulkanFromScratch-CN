# Vulkan 进阶

该章节主要基于Sascha Willems 的开源案例库（https://github.com/SaschaWillems/Vulkan）所写。同样，这一章很多内容也都仅仅是把原文用中文略带一些口语化的方法记录下来，所以强烈推荐一起学习的小伙伴们配合着原文一起食用。

本章节目录的顺序完全与开源案例库给出的顺序一致。